import { Component } from '@angular/core';

@Component({
  selector: 'app-text-area',
  templateUrl: './text-area.component.html',
  styleUrl: './text-area.component.css'
})
export class TextAreaComponent {
  buttonVisibility !: boolean;
  textAreaId !: string ;

  removeTextArea(id: string) {
  document.getElementById(id)?.remove();
  }
}
