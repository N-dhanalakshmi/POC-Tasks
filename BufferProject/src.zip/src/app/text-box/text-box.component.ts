import { Component } from '@angular/core';

@Component({
  selector: 'app-text-box',
  templateUrl: './text-box.component.html',
  styleUrl: './text-box.component.css'
})
export class TextBoxComponent {
buttonVisibility !: boolean;
textBoxId !: string ;

removeTextBox(id: string) {
document.getElementById(id)?.remove();
}
}
