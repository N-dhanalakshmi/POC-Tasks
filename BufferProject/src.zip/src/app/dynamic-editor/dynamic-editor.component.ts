import { Component , ViewChild, ViewContainerRef, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { MasterServiceService } from '../services/master-service.service';
import { TextBoxComponent } from '../text-box/text-box.component';
import { TextAreaComponent } from '../text-area/text-area.component';
import { DatePickerComponent } from '../date-picker/date-picker.component';
import { DropDownComponent } from '../drop-down/drop-down.component';
import { TableComponent } from '../table/table.component';

@Component({
  selector: 'app-dynamic-editor',
  templateUrl: './dynamic-editor.component.html',
  styleUrl: './dynamic-editor.component.css',
  encapsulation : ViewEncapsulation.None
})
export class DynamicEditorComponent {
  canvasElements: any[] = [];
  selectedComponent : any ;

  constructor(
    private router : Router,
    private service : MasterServiceService
    ) {}

  onDragStart(event: DragEvent, type: string) {
    event.dataTransfer?.setData('text', type);
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const type = event.dataTransfer?.getData('text');
    if (type) {
      this.insertElementAtCursor(type);
    }
  }

  insertElementAtCursor(type: string) {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      let newComponent;
      switch (type) {
        case 'textbox':
          this.selectedComponent = TextBoxComponent;
        break;

        case 'textarea':
          this.selectedComponent = TextAreaComponent;
        break;

        case 'datepicker':
          this.selectedComponent = DatePickerComponent;
        break;

        case 'dropdown':
          this.selectedComponent = DropDownComponent;
        break;

        case 'table':
          this.selectedComponent = TableComponent;
        break;

        default:
        break;
      }
      this.canvasElements.push(newComponent);
    }
  }

  showPreview() {
    this.service.setContent(document.getElementById('canvas'));
    this.router.navigate(['Preview']);
  }
}
