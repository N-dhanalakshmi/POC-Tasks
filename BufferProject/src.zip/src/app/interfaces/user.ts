
export interface Users
{
employeeId : number ;
name : string ;
email : string ;
password : string ;
dob : string ;
designation : string ;
department : string ;
address : string ;
phoneNumber : string ;
salary : string ;
doj : string ;
}
