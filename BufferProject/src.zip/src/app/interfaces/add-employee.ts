export interface AddUser{
    employeeId : number ;
    name : string ;
    email : string ;
    designation : string ;
    department : string ;
    phoneNumber : string ;
    password : string ;
    dob : string ;
    salary : number ;
    doj : string ;
    address : string ;
}
