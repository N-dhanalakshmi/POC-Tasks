export interface Template{
  templateId : number;
  template : string;
}
