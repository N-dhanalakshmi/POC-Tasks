export interface Employees{
  employeeId : number ;
  name : string ;
  email  : string ;
  designation  : string ;
  department  : string ;
}
