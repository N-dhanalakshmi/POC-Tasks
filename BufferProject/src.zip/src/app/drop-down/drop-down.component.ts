import { Component } from '@angular/core';

@Component({
  selector: 'app-drop-down',
  templateUrl: './drop-down.component.html',
  styleUrl: './drop-down.component.css'
})
export class DropDownComponent {

  buttonVisibility !: boolean;
  dropDownId !: string ;
  showOptions: boolean = false;
  noDropDown : boolean = false;

  showMenu() {
    this.showOptions = ! this.showOptions;
  }

  addOption(id: string) {
    const element = document.getElementById(id);
      if (element) {
        const label = prompt('Enter option label:');
        const value = prompt('Enter option value:');
        if (label && value) {
        const optionNode = document.createElement('option');
        optionNode.setAttribute('value', value);
        optionNode.textContent = label;
        element.appendChild(optionNode);
      }
    }
  }

  removeOption(id: string) {
    const element = document.getElementById(id) as HTMLSelectElement;
    const optionIndex = parseInt(prompt('Enter option index to remove:') || '0', 10);
        if (!isNaN(optionIndex) && optionIndex >= 0 ) {
           element.remove(optionIndex-1);
        }
  }

  removeDropDown(id: string) {
  document.getElementById(id)?.remove();
  this.noDropDown = true ;
  }
}
