import { Component } from '@angular/core';
import { last } from 'rxjs';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrl: './table.component.css'
})
export class TableComponent {
  noTable : boolean = false;
  showOptions : boolean = false;
  buttonVisibility !: boolean;
  tableId !: string  ;

  showMenu() {
  this.showOptions = !this.showOptions ;
  }

  addRow(id: string) {
    const element = document.getElementById(id) as HTMLTableElement;
    const columnCount = element.tHead?.rows[0].cells?.length;
    let tableData = '';
    if(columnCount){
    for (let length = 1; length <= columnCount; length++) {
        tableData += `<td>Cell ${length}</td>`;
    }
    const htmlContent = `<tr>${tableData}</tr>`;
    element.tBodies[0].insertAdjacentHTML('afterend', htmlContent);}
  }

  addColumn(id: string) {
    const element = document.getElementById(id) as HTMLTableElement;
    const rowCount = element.rows.length;
      const newHeaderCell = document.createElement('th');
      let headerCount = element.tHead?.rows[0].cells.length
      if(headerCount)
      newHeaderCell.textContent = `Header ${headerCount+1}`;
      element.tHead?.rows[0].appendChild(newHeaderCell);
      for (let row = 1; row <= rowCount; row++) {
      const newRowCell = document.createElement('td');
      newRowCell.textContent = `Cell ${element.rows[row].cells?.length + 1}`;
      element.rows[row].appendChild(newRowCell);
    }
  }

  removeRow(id: string) {
    const element = document.getElementById(id) as HTMLTableElement;
    const rowIndex = parseInt(prompt('Enter row place to remove') || '0' , 10 );
    if(rowIndex>0)
    element.deleteRow(rowIndex);
  }

  removeColumn(id: string) {
    const table = document.getElementById(id) as HTMLTableElement;
    const colIndex = parseInt(prompt('Enter column index to remove:') || '0', 10);
    const rowCount = table.rows.length;
    for (let i = 0; i < rowCount; i++) {
        table.rows[i].deleteCell(colIndex-1);
    }
  }

  removeTable(id: string) {
  document.getElementById(id)?.remove();
  this.showOptions = !this.showOptions
  this.noTable = true;
  }

  toggleMenu(){
    this.showOptions = ! this.showOptions;
  }

}
